/////////////////////////////////////////////////////////////
// Archivo: pruebas.sc
// Descripción: Casos de prueba para el Taller 4
// Tema: Colecciones y Expresiones For
// Organización: primero definición de secuencias base,
// luego pruebas por función.
/////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////
// BLOQUE 1: Definiciones base (una sola vez)
/////////////////////////////////////////////////////////////
val S_ejemplo_largo: Secuencia = Seq(20, 30, 10, 40, 15, 16, 17) 
val S_ejemplo_corto: Secuencia = Seq(20, 30, 10)
val S_vacia: Secuencia = Seq()
val S_unitaria: Secuencia = Seq(99)
val S_incremental_pura: Secuencia = Seq(1, 2, 3, 4, 5)
val S_decremental_pura: Secuencia = Seq(5, 4, 3, 2, 1)
val S_dos: Secuencia = Seq(1, 2)
val S_rep: Secuencia = Seq(10, 10)


/////////////////////////////////////////////////////////////
// BLOQUE 2: Pruebas para funciones
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//A. Pruebas para subSecuenciaAsoc
/////////////////////////////////////////////////////////////


//Caso 1: Secuencia de índices vacía
val prueba_assoc_1 = subSecuenciaAsoc(S_ejemplo_corto, Seq())
//Valor esperado: List()
assert(prueba_assoc_1 == List())

//Caso 2
val prueba_assoc_2 = subSecuenciaAsoc(S_ejemplo_largo, Seq(0, 2, 4))
// Valor esperado: List(20, 10, 15)
assert(prueba_assoc_2 == List(20, 10, 15))

//Caso 3
val prueba_assoc_3 = subSecuenciaAsoc(S_ejemplo_largo, Seq(1, 2, 4, 6))
// Valor esperado: List(30, 10, 15, 17)
assert(prueba_assoc_3 == List(30, 10, 15, 17))

// Caso 4 :secuencia unitaria.
val prueba_assoc_4 = subSecuenciaAsoc(S_unitaria, Seq(0))
// Valor esperado: List(99)
assert(prueba_assoc_4 == List(99))

// Caso 5: La secuencia completa. Indices deben ser 0 hasta n-1
val prueba_assoc_5 = subSecuenciaAsoc(S_incremental_pura, Seq(0, 1, 2, 3, 4))
// Valor esperado: List(1, 2, 3, 4, 5)
assert(prueba_assoc_5 == List(1, 2, 3, 4, 5))


/////////////////////////////////////////////////////////////
// B. Pruebas para incremental
/////////////////////////////////////////////////////////////


// Caso 1 trivial.
val prueba_inc_1 = incremental(Seq())
// Valor esperado: true
assert(prueba_inc_1 == true)

// Caso 2: Secuencia unitaria
val prueba_inc_2 = incremental(Seq(50))
// Valor esperado: true
assert(prueba_inc_2 == true)

// Caso 3: Subsecuencia estrictamente incremental 
val prueba_inc_3 = incremental(Seq(10, 15, 17))
// Valor esperado: true
assert(prueba_inc_3 == true)

// Caso 4: Subsecuencia no incremental
val prueba_inc_4 = incremental(Seq(30, 10, 40))
// Valor esperado: false
assert(prueba_inc_4 == false)

// Caso 5: Subsecuencia no incremental 
val prueba_inc_5 = incremental(Seq(20, 20, 40))
// Valor esperado: false
assert(prueba_inc_5 == false)

// Caso 6: Subsecuencia larga con violación en el medio (3 < 5, pero 5 no es < 4)
val prueba_inc_6 = incremental(Seq(3, 5, 4, 8, 9))
// Valor esperado: false
assert(prueba_inc_6 == false)


/////////////////////////////////////////////////////////////
// C. Pruebas para subSecuenciasDe
/////////////////////////////////////////////////////////////


// Caso 1: Secuencia vacía (N=0). 2^0 = 1 subsecuencia 
val prueba_subs_1 = subSecuenciasDe(S_vacia)
// Valor esperado: Set(List())
assert(prueba_subs_1 == Set(List()))

// Caso 2: Secuencia de longitud 1 (N=1). 2^1 = 2 subsecuencias
val prueba_subs_2 = subSecuenciasDe(S_unitaria)
// Valor esperado: Set(List(), List(99))
assert(prueba_subs_2 == Set(List(), List(99)))

// Caso 3: Secuencia de longitud 2, S = (1, 2). 2^2 = 4 subsecuencias

val resultado_esperado_3 = Set(List(), List(1), List(2), List(1, 2))
val prueba_subs_3 = subSecuenciasDe(S_dos)
// Valor esperado: Set(List(), List(1), List(2), List(1, 2))
assert(prueba_subs_3 == resultado_esperado_3)

val resultado_esperado_4: Set[Subsecuencia] = Set(
  List(), List(20), List(30), List(10),
  List(20, 30), List(20, 10), List(30, 10),
  List(20, 30, 10)
)
val prueba_subs_4 = subSecuenciasDe(S_ejemplo_corto)
assert(prueba_subs_4.size == 8)
assert(prueba_subs_4 == resultado_esperado_4)

// Caso 5: Secuencia con elementos repetidos

val prueba_subs_5 = subSecuenciasDe(S_rep)
// Valor esperado: Set(List(), List(10), List(10, 10))
assert(prueba_subs_5 == Set(List(), List(10), List(10, 10)))
assert(prueba_subs_5.size == 3)

/////////////////////////////////////////////////////////////
// D. Pruebas para subSecuenciasInc
/////////////////////////////////////////////////////////////

// Caso 1: Secuencia vacía → solo subsecuencia vacía
val prueba_incseq_1 = subSecuenciasInc(S_vacia)
// Valor esperado: Set(List())
assert(prueba_incseq_1 == Set(List()))

// Caso 2: Secuencia unitaria → subsecuencia vacía y el único elemento
val prueba_incseq_2 = subSecuenciasInc(S_unitaria)
// Valor esperado: Set(List(), List(99))
assert(prueba_incseq_2 == Set(List(), List(99)))

// Caso 3: Secuencia estrictamente incremental → todas las subsecuencias son incrementales
val prueba_incseq_3 = subSecuenciasInc(S_incremental_pura)
// Valor esperado: todas las combinaciones de una secuencia estrictamente creciente
assert(prueba_incseq_3.size == math.pow(2, S_incremental_pura.length).toInt)

// Caso 4: Secuencia decreciente pura → solo subsecuencias unitarias y vacía
val prueba_incseq_4 = subSecuenciasInc(S_decremental_pura)
// Valor esperado: List vacía y subsecuencias de un solo elemento
assert(prueba_incseq_4 == Set(List(), List(5), List(4), List(3), List(2), List(1)))

// Caso 5: Secuencia mixta (ejemplo del taller)
val prueba_incseq_5 = subSecuenciasInc(S_ejemplo_corto)
// Valor esperado: HashSet(List(30), List(), List(20), List(10), List(20, 30))
assert(prueba_incseq_5.contains(List(20, 30)))
assert(prueba_incseq_5.exists(_.isEmpty))
assert(prueba_incseq_5.size == 5)



/////////////////////////////////////////////////////////////
// E. Pruebas para subsecuenciaIncrementalMasLarga
/////////////////////////////////////////////////////////////

// Caso 1: Secuencia vacía
val prueba_maslarga_1 = subsecuenciaIncrementalMasLarga(S_vacia)
// Valor esperado: List()
assert(prueba_maslarga_1 == List())

// Caso 2: Secuencia unitaria
val prueba_maslarga_2 = subsecuenciaIncrementalMasLarga(S_unitaria)
// Valor esperado: List(99)
assert(prueba_maslarga_2 == List(99))

// Caso 3: Secuencia estrictamente incremental
val prueba_maslarga_3 = subsecuenciaIncrementalMasLarga(S_incremental_pura)
// Valor esperado: List(1, 2, 3, 4, 5)
assert(prueba_maslarga_3 == List(1, 2, 3, 4, 5))

// Caso 4: Secuencia decreciente pura
val prueba_maslarga_4 = subsecuenciaIncrementalMasLarga(S_decremental_pura)
// Valor esperado: cualquier elemento individual
assert(S_decremental_pura.contains(prueba_maslarga_4.head))
assert(prueba_maslarga_4.length == 1)

// Caso 5: Secuencia mixta (ejemplo del taller)
val prueba_maslarga_5 = subsecuenciaIncrementalMasLarga(S_ejemplo_largo)
// Valor esperado: List(10, 15, 16, 17)
assert(prueba_maslarga_5 == List(10, 15, 16, 17))



/////////////////////////////////////////////////////////////
// F. Pruebas para ssimlComenzandoEn
/////////////////////////////////////////////////////////////

// Caso 1: Último elemento → subsecuencia de un solo elemento
val prueba_ssiml_1 = ssimlComenzandoEn(6, S_ejemplo_largo)
// Valor esperado: List(17)
assert(prueba_ssiml_1 == List(17))

// Caso 2: Elemento que tiene mayores después (índice 0)
val prueba_ssiml_2 = ssimlComenzandoEn(0, S_ejemplo_largo)
// Valor esperado: podría empezar con 20 y continuar hasta 40 o más: List(20, 30, 40)
assert(prueba_ssiml_2.startsWith(Seq(20)))

// Caso 3: Elemento en mitad de la secuencia (índice 4, valor 15)
val prueba_ssiml_3 = ssimlComenzandoEn(4, S_ejemplo_largo)
// Valor esperado: List(15, 16, 17)
assert(prueba_ssiml_3 == List(15, 16, 17))

// Caso 4: Secuencia decreciente → cada llamada devuelve elemento unitario
val prueba_ssiml_4 = ssimlComenzandoEn(0, S_decremental_pura)
// Valor esperado: List(5)
assert(prueba_ssiml_4 == List(5))

// Caso 5: Ejemplo del enunciado del taller
val prueba_ssiml_5 = ssimlComenzandoEn(4, Seq(10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 22, 21, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11))
// Valor esperado: List(6, 22)
assert(prueba_ssiml_5 == List(6, 22))



/////////////////////////////////////////////////////////////
// G. Pruebas para subSecIncMasLargaV2
/////////////////////////////////////////////////////////////

// Caso 1: Secuencia vacía
val prueba_v2_1 = subSecIncMasLargaV2(S_vacia)
// Valor esperado: List()
assert(prueba_v2_1 == List())

// Caso 2: Secuencia unitaria
val prueba_v2_2 = subSecIncMasLargaV2(S_unitaria)
// Valor esperado: List(99)
assert(prueba_v2_2 == List(99))

// Caso 3: Secuencia estrictamente incremental
val prueba_v2_3 = subSecIncMasLargaV2(S_incremental_pura)
// Valor esperado: List(1, 2, 3, 4, 5)
assert(prueba_v2_3 == List(1, 2, 3, 4, 5))

// Caso 4: Secuencia decreciente pura
val prueba_v2_4 = subSecIncMasLargaV2(S_decremental_pura)
// Valor esperado: un solo elemento
assert(prueba_v2_4.length == 1)

// Caso 5: Ejemplo del taller (versión larga)
val prueba_v2_5 = subSecIncMasLargaV2(Seq(10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 22, 21, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11))
// Valor esperado: List(10, 22)
assert(prueba_v2_5 == List(10, 22))

/////////////////////////////////////////////////////////////
// Fin del archivo de pruebas
/////////////////////////////////////////////////////////////