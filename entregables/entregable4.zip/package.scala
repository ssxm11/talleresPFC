package object SubsecuenciaMasLarga{
 
  type Secuencia = Seq[Int]
  type Subsecuencia = Seq[Int]

  def subindices(i: Int, n: Int): Set[Seq[Int]] = {
    // dados i y n devuelve todas las posibles secuencias crecientes de enteros entre i y n
    if (i >= n) Set(Seq())
    else {
      val sinElActual: Set[Seq[Int]] = subindices(i + 1, n)
      val conElActual: Set[Seq[Int]] = for {
        subseq <- subindices(i + 1, n)
      } yield i +: subseq
      sinElActual ++ conElActual
    }
  }

  def subSecuenciaAsoc(s: Secuencia, inds: Seq[Int]): Subsecuencia = {
    for {
      indice <- inds
    } yield s(indice)
  }
  
  def subSecuenciasDe(s: Secuencia): Set[Subsecuencia] = {
 
  val n = s.length

 
  val todosLosIndices: Set[Seq[Int]] = subindices(0, n)

  
  val resultado: Set[Subsecuencia] = for {
    indices <- todosLosIndices
  } yield subSecuenciaAsoc(s, indices)

 
  resultado
}

  def incremental(s:Subsecuencia ):Boolean ={
    if (s.isEmpty || s.length == 1) true
  else {
    (for {
      (a, b) <- s.zip(s.tail)
      if a >= b
    } yield (a, b)).isEmpty
  }

  }
  def subSecuenciasInc(s: Secuencia): Set[Subsecuencia] = {
  for {
    sub <- subSecuenciasDe(s)
    if incremental(sub)
  } yield sub
}
 def subsecuenciaIncrementalMasLarga(s: Secuencia): Subsecuencia = {
  val incs = subSecuenciasInc(s)
  if (incs.isEmpty) List()
  else incs.maxBy(_.length)
}

  def ssimlComenzandoEn(i: Int, s: Secuencia): Subsecuencia = {
    // obtenemos todos los índices j donde s(j) > s(i)
  val mayores = for {
    j <- (i + 1) until s.length
    if s(j) > s(i)
  } yield ssimlComenzandoEn(j, s)  // recursión

  // Si no hay elementos mayores, la subsecuencia es solo s(i)
  if (mayores.isEmpty)
    Seq(s(i))
  else
    s(i) +: mayores.maxBy(_.length)  // concatenamos el mayor
  }
  def subSecIncMasLargaV2(s: Secuencia ): Subsecuencia ={
      if (s.isEmpty) Seq()  // caso base: secuencia vacía
  else {
    val subsecs = for {
      i <- 0 until s.length        // para cada posición posible
    } yield ssimlComenzandoEn(i, s) // hallamos la subsecuencia incremental desde s(i)
    
    subsecs.maxBy(_.length)        // nos quedamos con la más larga
  }
  }
}